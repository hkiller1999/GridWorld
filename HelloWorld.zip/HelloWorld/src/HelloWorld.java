public class HelloWorld{
    private String string_out;
    public void hello(){
        string_out = "Hello World!";
    }
    public String hello(){
        return string_out;
    }
    public static void main(String[] args){
     System.out.println("Hello World!");
    }

}