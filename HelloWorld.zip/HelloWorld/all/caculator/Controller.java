import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javax.script.ScriptException;
public class Controller {

    @FXML
    TextField cal1;

    @FXML
    TextField cal2;

    @FXML 
    TextField res;

    @FXML
    TextField operator;

    String option;
    String setans;

    @FXML
    public void getres(ActionEvent e) throws ScriptException
    {
        Double first = Double.parseDouble(cal1.getText());
        Double second = Double.parseDouble(cal2.getText());
        Double ans=0.0;
        switch (option)
        {
            case "+":
                ans = first + second;
                break;
            case "-":
                ans = first - second;
                break;
            case "*":
                ans = first * second;
                break;
            case "/":
                ans = first / second;
                break;
            default:
                break;
        }
        if (ans == Math.floor(ans)) setans=String.valueOf(ans.intValue());
        else setans=String.valueOf(ans);
        res.setText(setans);

    }

    @FXML
    public void Operator(ActionEvent e)
    {
        option = (String)((Button) e.getSource()).getText();
        operator.setText(option);
    }

}
